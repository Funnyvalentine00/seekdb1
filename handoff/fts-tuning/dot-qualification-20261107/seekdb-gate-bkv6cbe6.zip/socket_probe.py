#!/usr/bin/env python3
"""Standard-library only, one AF_UNIX attempt and one loopback TCP control per location.
No installations, compilation, SeekDB startup, alternate socket paths, or retries.
"""
import datetime, errno, hashlib, json, os, pathlib, platform, socket, sys, tempfile, traceback

WORKSPACE = pathlib.Path("/workspace/scratch/40bdaf6f35aa")
OUT = pathlib.Path(__file__).resolve().parent
LOG = open(OUT / "probe.raw.jsonl", "x", encoding="utf-8")
def emit(**obj):
    obj["utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    line = json.dumps(obj, ensure_ascii=False, sort_keys=True, default=repr)
    LOG.write(line + "\n"); LOG.flush()
    print(line, flush=True)

def step(location, protocol, stage, call):
    try:
        result = call()
    except Exception as exc:
        emit(location=location, protocol=protocol, stage=stage, status="failed",
             exception_type=type(exc).__name__, exception_repr=repr(exc),
             exception_str=str(exc), exception_args=exc.args,
             errno=getattr(exc, "errno", None),
             errno_name=errno.errorcode.get(getattr(exc, "errno", None)),
             strerror=getattr(exc, "strerror", None),
             filename=getattr(exc, "filename", None),
             filename2=getattr(exc, "filename2", None),
             traceback=traceback.format_exc())
        return False, None
    emit(location=location, protocol=protocol, stage=stage, status="passed", result=result)
    return True, result

STAGES = ["socket", "settimeout", "bind", "listen", "getsockname",
          "client_socket", "client_settimeout", "connect", "accept",
          "accepted_settimeout", "client_send", "server_recv",
          "server_send", "client_recv"]
def run_protocol(location, family, address):
    protocol = "AF_UNIX/SOCK_STREAM" if family == socket.AF_UNIX else "AF_INET/SOCK_STREAM"
    sockets = []
    idx = 0
    def do(stage, call):
        nonlocal idx
        idx = STAGES.index(stage)
        good, result = step(location, protocol, stage, call)
        if not good:
            for remaining in STAGES[idx + 1:]:
                emit(location=location, protocol=protocol, stage=remaining,
                     status="not_attempted", reason="Prerequisite stage failed; no retry.")
            raise StopIteration
        return result
    def make():
        obj = socket.socket(family, socket.SOCK_STREAM); sockets.append(obj); return obj
    def recv_expected(sock, expected):
        data = sock.recv(1024)
        if data != expected:
            raise RuntimeError("Unexpected received bytes: " + repr(data))
        return {"received_hex": data.hex(), "expected_hex": expected.hex()}
    try:
        server = do("socket", make)
        do("settimeout", lambda: server.settimeout(2.0))
        do("bind", lambda: server.bind(address))
        do("listen", lambda: server.listen(1))
        bound = do("getsockname", server.getsockname)
        client = do("client_socket", make)
        do("client_settimeout", lambda: client.settimeout(2.0))
        do("connect", lambda: client.connect(address if family == socket.AF_UNIX else bound))
        accepted, peer = do("accept", server.accept); sockets.append(accepted)
        do("accepted_settimeout", lambda: accepted.settimeout(2.0))
        do("client_send", lambda: client.sendall(b"probe-request"))
        do("server_recv", lambda: recv_expected(accepted, b"probe-request"))
        do("server_send", lambda: accepted.sendall(b"probe-response"))
        do("client_recv", lambda: recv_expected(client, b"probe-response"))
        emit(location=location, protocol=protocol, stage="summary", status="passed", errno=None)
        return True
    except StopIteration:
        emit(location=location, protocol=protocol, stage="summary", status="failed", failed_stage=STAGES[idx])
        return False
    finally:
        for number, sock in enumerate(reversed(sockets)):
            step(location, protocol, "close_" + str(number), sock.close)

emit(stage="environment", python=sys.version, platform=platform.platform(), cwd=os.getcwd(),
     uid=os.getuid(), pid=os.getpid(), artifact_directory=str(OUT),
     probe_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest())
original = os.getcwd()
results = []
for label, parent in [("workspace", WORKSPACE), ("tmp", pathlib.Path("/tmp"))]:
    ok, directory = step(label, "setup", "mkdtemp_exclusive",
        lambda p=parent: tempfile.mkdtemp(prefix="seekdb-unix-probe-", dir=str(p)))
    if not ok:
        results.append({"location": label, "setup": False}); continue
    ok, _ = step(label, "setup", "chdir", lambda: os.chdir(directory))
    if not ok:
        results.append({"location": label, "setup": False}); continue
    ok, _ = step(label, "setup", "mkdir_run", lambda: os.mkdir("run", 0o700))
    if not ok:
        results.append({"location": label, "setup": False}); os.chdir(original); continue
    emit(location=label, stage="case", directory=directory, cwd=os.getcwd(),
         address="run/sql.sock", run_exists=os.path.isdir("run"))
    unix_ok = run_protocol(label, socket.AF_UNIX, "run/sql.sock")
    tcp_ok = run_protocol(label, socket.AF_INET, ("127.0.0.1", 0))
    results.append({"location": label, "directory": directory, "unix_ok": unix_ok, "tcp_ok": tcp_ok})
    os.chdir(original)
emit(stage="final_summary", results=results, no_retries=True, seekdb_started=False,
     installed=False, compiled=False)
LOG.close()

