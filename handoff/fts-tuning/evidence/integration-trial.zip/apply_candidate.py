from pathlib import Path
import hashlib,json,subprocess
out=Path(__file__).resolve().parent;native=Path('/opt/codex-seekdb-20261030')
base='fdb8363f64363819fcf2307be95bcd10a5a7e4ba'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()==base
assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=native)
origin=out.parent/'20261102-beng-resource';source=json.loads((origin/'SOURCE_RECORD.json').read_text())
patch=origin/source['full_patch'];assert hashlib.sha256(patch.read_bytes()).hexdigest()==source['full_patch_sha256']
subprocess.run(['git','apply','--check',str(patch)],cwd=native,check=True)
subprocess.run(['git','apply',str(patch)],cwd=native,check=True)
subprocess.run(['git','add','--',*source['files']],cwd=native,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=native,text=True).splitlines())==set(source['files'])
subprocess.run(['git','diff','--cached','--check'],cwd=native,check=True)
subprocess.run(['git','commit','-m','perf(fts): normalize ASCII tokens in caller-owned storage'],cwd=native,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()
product=subprocess.check_output(['git','diff',base,head,'--binary','--','src'],cwd=native)
assert hashlib.sha256(product).hexdigest()==source['product_patch_sha256']
complete=subprocess.check_output(['git','diff',base,head,'--binary','--','src','unittest/storage/fts'],cwd=native)
assert complete==patch.read_bytes()
(out/'changes.patch').write_bytes(complete)
result={'base':base,'candidate':head,'branch':'codex/fts-beng-pr-20261102',
    'product_patch_sha256':source['product_patch_sha256'],'full_patch_sha256':source['full_patch_sha256'],
    'files':source['files'],'standalone_source':source['commit'],'no_file_sql_or_ai_delta':True}
(out/'SOURCE_RECORD.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
