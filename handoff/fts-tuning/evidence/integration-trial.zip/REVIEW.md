# Whole-PR review and execution rulings

Fresh read-only reviewer fts_pr_final_review independently verified fdb8363→9ed8c5f: exactly five FTS product files/two tests, product SHA d909d80f…09db and complete SHA d585a97c…246; no File SQL, AI, variables, benchmark/golden, credentials or binary delta. No confirmed Major/Blocker product finding.

One confirmed Major test-evidence gap: basic file→FTS smoke searches only literal-added hello, not CSV-derived Alice/Bob/Chen; it could pass with no imported rows indexed. Ruling: valid, verified against fixture and SQL. Keep the frozen timed batch intact; add file_rows_check.py after timing, requiring nonempty TOKENIZE for every actual CSV name, exact expected indexed IDs per name, positive rounded scores equal to independently literal-loaded data, and identical baseline/candidate output. Final verify.py requires this supplement; basic-smoke flag alone cannot satisfy integration acceptance. This is the one focused fix pass, not a product change or new timing attempt.

Port preflight: initial connect_ex had no timeout and waited before instance creation. A guarded attempted stop refused once the runner had advanced into validation, so no signal was sent and no sample discarded. Retain the actual batch and frozen scripts. Supplement uses a local bind probe. This was a startup delay, not a benchmark result or justification to repeat sampling.

Rulings on declined behaviors:

- Integrated runtime/builds were pending at review time. Accept only actual final logs and VERIFICATION.json, not reviewer inference. Both normal builds and focused tests completed before measurement; full trial/supplement must finish before publication claims.
- Qualified gain is unsupported by this deliberately exploratory protocol. Keep performance_qualified=false and Draft PR, even with favorable point estimates; never use old16.8%.
- Old-server preservation requires final hash/start-tick/protected-source/process checks in verify.py. Safeguards alone do not establish completion.
- Final handoff/PR wording is written after results. Use raw paired mean/interval, controls and lifetime RSS with scope limits; do not claim an improvement from a local probe or clipped score.
- Baseline File SQL/AI defects belong to their owners; only prove no product delta and record no-regression outcomes. Do not expand this PR into fixes for other tasks.

No minor/nit backlog and no second reviewer requested.
