from pathlib import Path
import hashlib,json,math,statistics,subprocess,sys
out=Path(__file__).resolve().parent;native=Path('/opt/codex-seekdb-20261030')
sys.path.insert(0,str(out/'support'))
from analyze import validate,signed_improvement
s=json.loads((out/'state.json').read_text());source=json.loads((out/'SOURCE_RECORD.json').read_text())
assert s['status']=='exploratory_complete' and len(s['runs'])==8
assert s['protected_before']==s['protected_after'] and s['old_server_unchanged']
assert Path('/proc/7902/stat').read_text().rsplit(')',1)[1].split()[19]==s['old_server_start_ticks']
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
assert sha(Path('/proc/7902/exe'))==s['old_server_binary_sha256']
assert sha(out/'run.py')==s['runner_sha256'] and sha(out/'harness.py')==s['harness_sha256']
patch=subprocess.check_output(['git','diff',source['base'],source['candidate'],'--binary','--','src','unittest/storage/fts'],cwd=native)
assert patch==(out/'changes.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==source['full_patch_sha256']
assert not subprocess.check_output(['git','diff',source['candidate'],'HEAD','--','src','unittest'],cwd=native)
assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=native)
for tag in ('baseline','candidate'):
    build=json.loads((out/(tag+'-build.json')).read_text());assert build['exit_code']==0 and build['status']=='built'
    assert sha(Path(build['saved_binary']))==build['binary_sha256']
assert sha(native/'build_release/src/observer/seekdb')==json.loads((out/'candidate-build.json').read_text())['binary_sha256']
assert all(r['exit_code']==0 for r in json.loads((out/'green-tests.json').read_text()))
for run in s['runs']:
    assert run['completed'] and run['correctness_passed'] and len(run['official_cases'])==15
    assert run.get('file_fts_smoke_passed')
    if run['file_sql_passed']:
        assert b'\nexit_code=0\n' in (out/run['tag']/'file_sql_basic.log').read_bytes()
    for case in run['official_cases']:
        assert case['exit_code']==0 and b'\nexit_code=0\n' in (out/run['tag']/(case['name']+'.log')).read_bytes()
    label='before' if run['version']=='original' else 'after'
    validate(Path(run['report']),label)
    build=json.loads((out/('baseline-build.json' if label=='before' else 'candidate-build.json')).read_text())
    assert run['binary_sha256']==build['binary_sha256'] and run['source_commit']==build['source_commit']
    semantic=(out/run['tag']/'semantic.out').read_text().split('\nexit_code=')[0].split('\n',1)[1]
    assert semantic==(out/'semantic-original.out').read_text()
focus=json.loads((out/'file-rows-check/state.json').read_text())
assert focus['status']=='passed' and len(focus['runs'])==2 and all(r['actual_file_rows_verified'] for r in focus['runs'])
assert focus['protected_before']==focus['protected_after']==s['protected_after']
for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:exe=(p/'exe').resolve(strict=True)
    except (FileNotFoundError,ProcessLookupError,PermissionError):continue
    assert exe.parent!=Path('/opt/codex-fts-integration-pr-20261102/bin')
result=json.loads((out/'RESULT.json').read_text());changes=[]
for i in range(1,4):
    a=validate(out/'trial'/f'before-{i:02}.txt','before');b=validate(out/'trial'/f'after-{i:02}.txt','after')
    changes.append(signed_improvement(a,b))
point=statistics.mean(changes);half=4.302653*statistics.stdev(changes)/math.sqrt(3)
assert math.isclose(point,result['mean_improvement'],abs_tol=1e-12)
assert all(math.isclose(a,b,abs_tol=1e-12) for a,b in zip([point-half,point+half],result['student_t_95_interval']))
record={'verified':True,'base':source['base'],'candidate':source['candidate'],'full_patch_sha256':source['full_patch_sha256'],
    'normal_integrated_builds':2,'reports':8,'trial_pairs':3,'official_fts_per_restart':15,
    'official_file_sql_all_passed':all(r.get('file_sql_passed') for r in s['runs']),
    'exact_sql_differential':True,'actual_file_rows_index_tokens_ids_scores_verified':True,
    'protected_files':len(s['protected_after']),'old_server_unchanged':True,'new_servers_running':0,
    'mean_improvement':point,'student_t_95_interval':result['student_t_95_interval'],
    'exploratory_only':True,'performance_qualified':False,'draft_pr':True}
(out/'VERIFICATION.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
