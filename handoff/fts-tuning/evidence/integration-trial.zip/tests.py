from pathlib import Path
import json,re,shlex,subprocess,sys
out=Path(__file__).resolve().parent;native=Path('/opt/codex-seekdb-20261030')
tag=sys.argv[1];assert tag in ('red','green')
assert not (out/(tag+'-tests.json')).exists()
target=Path('/opt/codex-fts-integration-probes-20261102');target.mkdir(exist_ok=True)
flags=[];s=(native/'build_release/src/storage/CMakeFiles/ob_storage.dir/flags.make').read_text()
for key in ('CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS'):flags+=shlex.split(re.search('^'+key+r' = (.*)$',s,re.M).group(1))
original=shlex.split((native/'build_release/src/observer/CMakeFiles/seekdb.dir/link.txt').read_text())
sources=[('capacity',native/'unittest/storage/fts/test_beng_owned_capacity.cpp')]
if tag=='green':sources.append(('ownership',native/'unittest/storage/fts/test_beng_owned_output.cpp'))
result=[]
for name,source in sources:
    obj=target/(name+'-'+tag+'.o');exe=target/(name+'-'+tag)
    compile=[original[0],*flags,'-c',str(source),'-o',str(obj)]
    link=[a for a in original if a not in ('CMakeFiles/ob_main.dir/main.cpp.o','CMakeFiles/ob_main.dir/ob_command_line_parser.cpp.o')]
    link[1:1]=[str(obj)];link[link.index('-o')+1]=str(exe)
    commands=[compile,link,[str(exe)]]
    (out/(name+'-'+tag+'-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
    with (out/(name+'-'+tag+'-build.log')).open('x') as log:
        for command in commands[:2]:subprocess.run(command,cwd=native/'build_release/src/observer',stdout=log,stderr=subprocess.STDOUT,timeout=240,check=True)
    with (out/(name+'-'+tag+'-result.log')).open('x') as log:
        run=subprocess.run(commands[2],stdout=log,stderr=subprocess.STDOUT,timeout=60)
        log.write('\nexit_code='+str(run.returncode)+'\n')
    output=(out/(name+'-'+tag+'-result.log')).read_text();print(output)
    assert run.returncode==(1 if tag=='red' else 0)
    if tag=='red':assert 'caller.requested==bytes' in output
    result.append({'name':name,'exit_code':run.returncode,'expected_failure':tag=='red'})
(out/(tag+'-tests.json')).write_text(json.dumps(result,indent=2)+'\n')
