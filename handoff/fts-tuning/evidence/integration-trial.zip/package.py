"""Build a reviewable #6-only handoff after actual integrated verification."""
from pathlib import Path
import hashlib,json,shlex,subprocess,zipfile
out=Path(__file__).resolve().parent;native=Path('/opt/codex-seekdb-20261030')
source=json.loads((out/'SOURCE_RECORD.json').read_text())
verification=json.loads((out/'VERIFICATION.json').read_text());assert verification['verified']
result=json.loads((out/'RESULT.json').read_text());state=json.loads((out/'state.json').read_text())
summary=json.loads((out/'trial/summary.json').read_text())
builds={tag:json.loads((out/(tag+'-build.json')).read_text()) for tag in ('baseline','candidate')}
assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=native)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()==source['candidate']
handoff=native/'handoff/fts-tuning';(handoff/'logs').mkdir(parents=True,exist_ok=True);(handoff/'evidence').mkdir(exist_ok=True)
written=[]
def write(name,content):
    p=handoff/name;p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.read_bytes()!=content.encode():
        backup=out/'prior-handoff'/name;backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(p.read_bytes())
    p.write_text(content);written.append(p.relative_to(native).as_posix())
def pct(x):return f'{x*100:+.2f}%'
metric_rows='\n'.join('| '+k+' | '+pct(v)+' |' for k,v in result['metric_improvements'].items())
control=json.loads((out/'control.json').read_text())
text=f'''# #6 Beng ASCII 归一化优化：整合版探索性 PR

## 1. 题目与验收标准

Issue #6。本组只交付 FTS；目标分支 feat/seekdb-all，固定基线 {source['base']}，产品候选 {source['candidate']}。状态：整合构建和功能回归通过，性能结果仅为探索，PR 保持 Draft，不建议据此直接合并或宣称比赛提分。

## 2. 接口契约

TOKENIZE/MATCH、parser名称/属性、词频/数组顺序保持原语义。Beng 归一化输出由调用方 allocator 持有；ASCII且mbminlen=1/casedn_multiply=1时直接生成，其他文本私有scratch归一化后按实际长度复制。scratch每token复用，调用方token可在parser销毁后继续消费；不跨调用缓存输入。默认分析路径不变，Beng关闭grouping。

#2已有SQL行源、enable_file_sql和secure_file_priv接线不改。使用整合版定义及生成链，不能搬入独立FileSQL旧变量ID/生成文件。文件文本通过现有SQL列进入TOKENIZE/存储FTS，无新增跨模块API。

## 3. 改动文件清单

五个产品文件：src/share/text_analysis/ob_text_analyzer.{{h,cpp}}、ob_token_stream.{{h,cpp}}，src/storage/fts/ob_beng_ft_parser.cpp。两项真实回归位于unittest/storage/fts/test_beng_owned_output.cpp与test_beng_owned_capacity.cpp。changes.patch只含这七个文件，SHA256 {source['full_patch_sha256']}。其余本PR文件都是本handoff的证据/文档；无#2/AI/benchmark/金样改动。

## 4. 构建与运行命令

真实构建环境：/opt/codex-seekdb-20261030，Ubuntu22.04，正常Release make -C build_release -j4。基线先执行src/sql/parser/gen_parser.sh和内表generate_inner_table_schema.py生成ignored构建输入；未改受版本控制的基线源码。完整命令与退出码见logs/build.log。

基线二进制SHA256：{builds['baseline']['binary_sha256']}。
候选二进制SHA256：{builds['candidate']['binary_sha256']}。
源码产品提交与后续仅文档提交分开记录，后者不改变受测产品树。

独立实例/opt/codex-fts-integration-pr-20261102，端口2891。固定ERROR日志、server CPU0-3/client4、每次原始init与回归后20s冷却。实际服务器/客户端命令、环境及退出码均在证据包；旧2881未切换。

复测时在干净目标±本补丁两版正常构建，依次原始init、官方mysqltest fts_index/file_sql，再运行原脚本：

```bash
LABEL=before ROWS=20000 BATCH=500 ROUNDS=3000 QUERY_ROUNDS=200 SAMPLES=3 WARMUP=30 SKIP_LOAD=0 OUTPUT=/tmp/fts-before.txt bash tools/benchmark/fts_large_bench.sh
python3 tools/benchmark/fts_large_bench_score.py /tmp/fts-before.txt
```

MYSQL连接参数按新实例设置。after使用同参LABEL=after；不得覆盖历史输出或直接重放封存的一次性runner。

## 5. 官方与自测结果

两版正常构建退出0；候选真实容量/ownership测试通过。8次完整重启均官方FTS15/15；FileSQL全部通过：{verification['official_file_sql_all_passed']}。有序SQL及错误差分一致，{verification['protected_files']}项官方输入不变。继承的LOB/不支持字符集错误保留，不算功能扩展。

独立补充的file_rows_check对CSV实际Alice/Bob/Chen逐行验证：非空TOKENIZE、实际预期命中ID和正分数，与等价字面量数据完全一致，原版/候选输出一致。不能仅凭早先查询额外字面量hello的basic-smoke标记宣称此链路通过。

## 6. 性能结果与日志

一对同版A/A诊断：{pct(control['paired_weighted_change'])}，单对不能建立噪声置信区间。三对AB/BA/AB完整固定负载，综合配对耗时改善均值 **{pct(result['mean_improvement'])}**，95% Student-t区间 **[{pct(result['student_t_95_interval'][0])}, {pct(result['student_t_95_interval'][1])}]**。正数表示耗时降低，负数表示回退；全部样本保留，不与旧窗口混池。

| 指标 | 三对平均耗时改善 |
| --- | ---: |
{metric_rows}

四类hits每份报告均8001/11000/7332/20。服务器生命周期峰值RSS均值相对变化 {pct(result['rss_mean_change'])}，包含重启后的回归准备阶段，不等于仅benchmark峰值或分配器容量。CPU与逐份RSS在benchmark-before/after.json及原始resources.json。

官方CI参照分：before {summary['official_reference']['before']['score']}，after {summary['official_reference']['after']['score']}；本地参照分不等于正式平台得分。benchmark-before/after.json保留三份报告、聚合定义、源码和二进制身份，evidence/reports包含原始文本和官方评分输出。

logs/build.log、verify.log、test.log、notes.log提供命令/退出码和结果索引；evidence/integration-trial.zip保存全部原始回归/bench/server日志、失败/审查记录、脚本及逐文件SHA清单。

## 7. 已知风险与结论边界

本批只有3对、1对A/A，属于快速效果试验，performance_qualified=false；不替代更强环境校准。即使某些门槛满足，也不升级为已证实综合收益。旧16.8%只属于已修正前的局部路径，不适用于此版本。

ASCII扫描本身有成本；Unicode非ASCII回退精确复制是避免保留容量回退的取舍。有限词/charset/OOM覆盖不保证穷尽；没有所有grouping组合的生命周期保证。当前数据只支持本次测试范围。独立审查无产品Major/Blocker；一项文件行索引覆盖缺口由上述补充测试修正，见notes.log。

## 8. 回滚与交付状态

基线 {source['base']} 保持不变。若不接受此候选，继续使用目标基线；已合入时可单独revert产品提交 {source['candidate']}，再正常重建，不回退其他任务。不要reset现有工作或删除数据。

新实例已停止、数据保留；旧2881/PID7902启动身份与二进制未变。仅推送专用codex/fts-beng-pr-20261102分支并创建Draft PR，未合并或提交比赛平台。后续由队长/CI根据独立环境复测决定是否接受#6优化。
'''
write('README.md',text);write('changes.patch',(out/'changes.patch').read_text())
buildlog='\n'.join('=== '+tag+' ===\n'+(out/(tag+'-build.log')).read_text(errors='replace') for tag in ('baseline','candidate'))
write('logs/build.log',buildlog)
verifylog='Integrated full original test drivers; complete raw outputs in evidence ZIP.\n'
for run in state['runs']:
    verifylog+='\n'+run['tag']+' source='+run['source_commit']+' binary='+run['binary_sha256']+'\n'
    for case in run['official_cases']:
        raw=(out/run['tag']/(case['name']+'.log')).read_bytes()
        verifylog+=raw.split(b'\n',1)[0].decode(errors='replace')+'\ncase='+case['name']+' exit_code='+str(case['exit_code'])+'\n'
    raw=(out/run['tag']/'file_sql_basic.log').read_bytes();verifylog+=raw.split(b'\n',1)[0].decode(errors='replace')+'\nfile_sql_passed='+str(run['file_sql_passed'])+'\n'
write('logs/verify.log',verifylog)
testlog=''
for name in ('capacity','ownership'):testlog+='\n'+name+'\n'+(out/(name+'-green-commands.json')).read_text()+(out/(name+'-green-result.log')).read_text()
for tag in ('original','candidate'):
    testlog+='\nActual file rows '+tag+'\n'+(out/'file-rows-check'/tag/'check.out').read_text()+(out/'file-rows-check'/tag/'verified.json').read_text()
write('logs/test.log',testlog)
write('logs/notes.log',(out/'PROTOCOL.md').read_text()+'\n'+(out/'REVIEW.md').read_text()+'\n'+json.dumps(result,indent=2)+'\n')
for label,tag in (('before','baseline'),('after','candidate')):
    raw=[json.loads((out/'trial'/f'{label}-{i:02}.resources.json').read_text()) for i in range(1,4)]
    body={'source_commit':builds[tag]['source_commit'],'binary_sha256':builds[tag]['binary_sha256'],
        'aggregation':'median of three complete-run means; paired mean/CI in README and RESULT.json',
        'median_metrics':summary['medians'][label],'runs':summary['all_report_metrics'][label],
        'resources':raw,'exploratory_only':True,'performance_qualified':False}
    write('benchmark-'+label+'.json',json.dumps(body,indent=2)+'\n')
    for i in range(1,4):
        report=out/'trial'/f'{label}-{i:02}.txt'
        write('evidence/reports/'+report.name,report.read_text())
        argv=['python3',str(native/'tools/benchmark/fts_large_bench_score.py'),str(report)]
        run=subprocess.run(argv,capture_output=True,text=True,timeout=30);assert run.returncode==0
        write('evidence/reports/'+report.stem+'-score.log','COMMAND '+shlex.join(argv)+'\n'+run.stdout+run.stderr+'\nexit_code=0\n')
archive=handoff/'evidence/integration-trial.zip'
payload=[p for p in out.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('PACKAGE.json','PR_RECORD.json','PR_BODY.md') and p.suffix!='.bundle']
manifest={p.relative_to(out).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in payload}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in payload:z.write(p,p.relative_to(out).as_posix())
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
digest=hashlib.sha256(archive.read_bytes()).hexdigest();written.append(archive.relative_to(native).as_posix())
write('evidence/integration-trial.zip.sha256',digest+'  integration-trial.zip\n')
package={'base':source['base'],'product_commit':source['candidate'],'handoff_paths':written,
    'archive_sha256':digest,'archive_entries':len(payload),'all_payload_hashes_and_crc_verified':True,'draft':True}
(out/'PACKAGE.json').write_text(json.dumps(package,indent=2)+'\n')
body=f'''Beng 的 ASCII 归一化直接使用调用方内存，省去第二次分配和复制；非 ASCII 保留精确长度复制，避免大小写转换缩短后保留多余容量。仅修改 #6 五个产品文件和两项回归，基于 `feat/seekdb-all` 的 `{source['base'][:7]}`，不改 File SQL/AI 接口。

两版正常 Release、FTS15/15、容量/生命周期和实际 CSV 文本到 TOKENIZE/索引/MATCH 的差分通过。File SQL 官方无回归检查全部通过：{verification['official_file_sql_all_passed']}。完整命令、原始日志及校验包见 [交接记录](https://github.com/Funnyvalentine00/seekdb1/blob/codex/fts-beng-pr-20261102/handoff/fts-tuning/README.md)。

三对完整负载的探索性综合耗时改善均值 **{pct(result['mean_improvement'])}**，95%区间 **[{pct(result['student_t_95_interval'][0])}, {pct(result['student_t_95_interval'][1])}]**；生命周期峰值RSS均值变化 **{pct(result['rss_mean_change'])}**。四类hits均为8001/11000/7332/20。

保持 **Draft**：同版A/A差异 {pct(control['paired_weighted_change'])}，且仅三对对照，尚未取得正式性能资格；旧16.8%局部诊断不适用，本地参照分不等于平台得分。请用独立环境/CI复测后决定是否接受，不据此直接合并。

Refs #6
'''
(out/'PR_BODY.md').write_text(body)
print(json.dumps(package,indent=2))
