# SDD ledger — plan: docs/superpowers/plans/2026-11-02-fts-integration-pr.md

User: approved next stage, finish optimization promptly and submit PR to try effect. Push/PR authorized, merge/platform submission not authorized. No more new optimizations.

Pre-flight:35a04a5 exact cumulative patch consumes original FTS files; targetfdb8363 has identical five files and admits complete patch. Baseline build is prerequisite for fair integrated trial; prior standalone binary cannot serve as integrated before. Source-only read checks confirmed native35a04a5 clean and remote target unchanged. Reuse existing native isolated experiment checkout, no new worktree needed.

Ruling: short trial batch is explicitly exploratory; one A/A control pair cannot certify noise. Retain A/B data even if diagnostic noise is high, but never qualify it using old16.8%. Publish Draft PR on inconclusive evidence or baseline blocker, with exact limitations, to honor requested quick PR handoff without unrelated repairs.

Task1/2/3 complete: targetfdb8363 normal parser/inner-table generation and Release built c9347067…1b6c; candidate9ed8c5f exact seven-file patch normally built5d9a1889…f5cd; focused ownership/capacity tests green. No FileSQL/AI/generated source delta.
Task4 timing complete:8reports (oneA/A pair and3AB/BA/AB pairs), every restartFTS15/15 and FileSQL1/1,45protected files unchanged, semantic differential equal, old7902 unchanged, newserver stopped after batch. Paired mean+0.987920%,95%t[-0.713028%,+2.688869%], A/A+9.101584%, lifetimepeakRSSmean+8.579710%. Point/interval/buildcategory/control/RSS gates failed; exploration only, performance_qualified=false, Draft PR required. Do not claim a code speedup or memory reduction. Both official reference scores100 are clipped local references, not platform scores.
Review: no confirmed productMajor/Blocker; one actual-file-row smoke coverage gap accepted. Frozen batch retained unchanged; file_rows_check.py supplement now running, asserting expected nonempty file-derived tokens/indexIDs/scores. No new timing attempt or product change.
Task5/6 pending final supplement/verification, handoff/archive, push and DraftPR. User explicitly authorized push/PR; no merge/platform submission.
