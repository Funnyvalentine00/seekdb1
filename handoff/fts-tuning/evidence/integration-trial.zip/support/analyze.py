"""Analyze untouched official reports using the official category weights."""
import copy
import importlib.util
import itertools
import json
from pathlib import Path
import random
import re
import statistics as st
import sys

REPO = Path('/opt/codex-seekdb-20261030')
spec = importlib.util.spec_from_file_location('official_score', REPO / 'tools/benchmark/fts_large_bench_score.py')
official = importlib.util.module_from_spec(spec)
spec.loader.exec_module(official)
REFERENCE = official.load_baseline(REPO / 'tools/benchmark/fts_large_bench_baseline.json')
KEYS = list(itertools.chain.from_iterable(REFERENCE['score_categories'].values()))
HITS = {'query_cn_hits': 8001, 'query_beng_hits': 11000, 'query_mixed_hits': 7332, 'query_limit_hits': 20}


def validate(path, label):
    report = official.load_report(path)
    official.check_config(report, REFERENCE, False)
    assert all(report.get(k) == v for k, v in HITS.items()), 'Incorrect/missing hits'
    assert all(report.get(k, 0) > 0 for k in KEYS), 'Missing/nonpositive metric'
    labels = [line.split(':', 1)[1].strip() for line in path.read_text().splitlines() if line.startswith('label:')]
    assert labels == [label], f'Unexpected report label: {labels}'
    return report


def signed_improvement(before, after):
    baseline = copy.deepcopy(REFERENCE)
    baseline['baseline_metrics'] = before
    return official.calculate_score(after, baseline)['mean_improvement']


def reference_delta(before, after):
    return st.mean(st.mean((before[k] - after[k]) / REFERENCE['baseline_metrics'][k] for k in metrics)
                   for metrics in REFERENCE['score_categories'].values())


def analyze(directory):
    reports = {label: [validate(p, label) for p in sorted(directory.glob(f'{label}-*.txt'))] for label in ('before', 'after')}
    assert len(reports['before']) == len(reports['after']) > 0
    medians = {label: {k: st.median(r[k] for r in values) for k in values[0]} for label, values in reports.items()}
    local = copy.deepcopy(REFERENCE)
    local['baseline_metrics'] = medians['before']
    result = {'runs_per_version': len(reports['before']), 'aggregation': 'median of complete-run means; no outlier removal',
              'medians': medians, 'local_equivalent': official.calculate_score(medians['after'], local),
              'official_reference': {label: official.calculate_score(value, REFERENCE) for label, value in medians.items()},
              'all_report_metrics': reports}
    # Resample matched pair numbers together; fixed seed. Small n is explicitly a limitation.
    count = len(reports['before'])
    rng = random.Random(20261031)
    draws = []
    reference_draws = []
    for _ in range(10000):
        indices = [rng.randrange(count) for _ in range(count)]
        values = {label: {k: st.median(reports[label][i][k] for i in indices) for k in KEYS} for label in reports}
        draws.append(signed_improvement(values['before'], values['after']))
        reference_draws.append(reference_delta(values['before'], values['after']))
    draws.sort()
    result['paired_bootstrap'] = {'seed': 20261031, 'resamples': 10000, 'percentile_95_interval': [draws[249], draws[9749]],
        'warning': 'Exploratory interval with few pairs and background drift; not individual-query latency or a guarantee.'}
    result['pair_signed_improvement'] = [signed_improvement(reports['before'][i], reports['after'][i]) for i in range(count)]
    reference_draws.sort()
    result['official_unclipped_delta'] = {
        'point': reference_delta(medians['before'], medians['after']),
        'paired_bootstrap_95_interval': [reference_draws[249], reference_draws[9749]],
        'definition': 'after mean_improvement minus before mean_improvement against the unchanged official CI reference; fraction units'}
    resources = {label: [json.loads(p.read_text()) for p in sorted(directory.glob(f'{label}-*.resources.json'))] for label in reports}
    result['resources'] = resources
    result['resource_summary'] = {label: {k: {'min': min(row[k] for row in rows), 'median': st.median(row[k] for row in rows), 'max': max(row[k] for row in rows)}
        for k in ('server_lifetime_peak_rss_kib', 'cpu_seconds', 'wall_seconds')} for label, rows in resources.items() if rows}
    result['raw_batch_average_latency_ms'] = {
        p.stem: [(m.group(1), int(m.group(2)), float(m.group(3))) for m in re.finditer(r'^\s+(\w+): sample=(\d+)/\d+.*avg_ms=([0-9.]+)', p.read_text(), re.MULTILINE)]
        for label in reports for p in sorted(directory.glob(f'{label}-*.log')) if not p.name.endswith('.switch.log')}
    (directory / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('runs_per_version', 'paired_bootstrap', 'pair_signed_improvement')}, indent=2))
    print('Local weighted time reduction:', result['local_equivalent']['mean_improvement'])
    print('Official reference scores:', {k: v['score'] for k, v in result['official_reference'].items()})
    return result


if __name__ == '__main__':
    analyze(Path(sys.argv[1]))
