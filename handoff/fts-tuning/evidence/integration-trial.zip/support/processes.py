"""Terminate a managed local command's process group on timeout or interruption."""
import os
import signal
import subprocess


def terminate_group(process):
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass
    # The direct child may exit before its descendants. Kill the group either way.
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    process.wait()


def run_managed(argv, *, timeout, **kwargs):
    process = subprocess.Popen(argv, start_new_session=True, **kwargs)
    try:
        return process.wait(timeout=timeout)
    except BaseException:
        terminate_group(process)
        raise
