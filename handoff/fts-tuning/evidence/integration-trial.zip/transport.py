"""Execute only the official File SQL fixture operations on the local WSL instance.

No general SSH fallback, credentials, shell evaluation, SQL substitution or golden
editing. The original include's loopback operations act on the same local paths.
"""
import base64
from pathlib import Path
import shutil
import sys

INSTANCE = Path('/opt/codex-fts-integration-pr-20261102')
FIXTURE = INSTANCE / 'data_for_mysqltest_file_sql'
SOURCE = Path('/opt/codex-seekdb-20261030/tools/deploy/mysql_test/test_suite/file_sql/data')
ALLOWED = {'basic.csv', 'basic.jsonl', 'invalid.txt', 'simple.parquet', 'simple.parquet.b64', 'export.csv'}


def check_fixture():
    assert not FIXTURE.is_symlink() and FIXTURE.resolve().parent == INSTANCE.resolve()
    if FIXTURE.exists():
        assert FIXTURE.is_dir()
        assert all(not p.is_symlink() and p.is_file() and p.name in ALLOWED for p in FIXTURE.iterdir())


def main(args):
    check_fixture()
    mode, *arguments = args
    if mode == 'ssh':
        assert len(arguments) == 2 and arguments[0] == '127.0.0.1', 'Only verified loopback fixture operations supported'
        command = arguments[1]
        if command == 'true':
            return
        if command == f'rm -rf "{FIXTURE}" && mkdir -p "{FIXTURE}"':
            if FIXTURE.exists():
                shutil.rmtree(FIXTURE)
            FIXTURE.mkdir()
        elif command == f'base64 -d "{FIXTURE}/simple.parquet.b64" > "{FIXTURE}/simple.parquet" && rm -f "{FIXTURE}/simple.parquet.b64"':
            payload = b''.join((FIXTURE / 'simple.parquet.b64').read_bytes().split())
            (FIXTURE / 'simple.parquet').write_bytes(base64.b64decode(payload, validate=True))
            (FIXTURE / 'simple.parquet.b64').unlink()
        elif command == f'rm -rf "{FIXTURE}"':
            if FIXTURE.exists():
                shutil.rmtree(FIXTURE)
        else:
            raise ValueError('Unrecognized fixture command; refusing execution')
    elif mode == 'scp':
        if arguments and arguments[0] == '-q':
            arguments.pop(0)
        assert len(arguments) >= 2 and arguments[-1] == f'127.0.0.1:{FIXTURE}/'
        assert FIXTURE.is_dir()
        for name in arguments[:-1]:
            path = Path(name)
            assert not path.is_symlink() and path.resolve().parent == SOURCE.resolve()
            assert path.name in ALLOWED and path.is_file()
            shutil.copy2(path, FIXTURE / path.name)
    else:
        raise ValueError('Unknown transport')


if __name__ == '__main__':
    try:
        main(sys.argv[1:])
    except (AssertionError, ValueError) as error:
        print('Fixture transport rejected:', str(error), file=sys.stderr)
        raise SystemExit(2)
