# FTS integration qualification and PR closeout

> Execute inline with executing-plans. User approved integration validation and explicitly requested a prompt PR to try the optimization. This authorizes a dedicated branch push and PR creation; it does not authorize merging or platform submission. No further optimization iterations.

**Goal:** Deliver a #6-only PR against feat/seekdb-all with honest integrated correctness and fixed-workload performance evidence.
**Architecture:** Pin targetfdb8363f64363819fcf2307be95bcd10a5a7e4ba; reuse clean native experimental checkout with new codex/fts-beng-pr-20261102 branch. First build/seal unmodified integration baseline, then apply exact tested35a04a5 cumulative product+tests patch and build/seal candidate. Keep File SQL and AI code identical. Preserve all failures and old source/binaries/instances.
**Tech Stack:** Existing native Release build, original mysqltest/FTS benchmark/scorer, serial Python harness and GitHub PR tools.
**Spec:** handoff/fts-tuning/INTEGRATION_CONTRACT.md; Issue6 source snapshot; coordination/issue-6/20261102-beng-resource/SOURCE_RECORD.json.

## Constraints and protocol

Only five allowed FTS product files and the two existing ownership/capacity tests, plus handoff evidence. No #2 fixes or benchmark/input/golden edits. Old2881/PID7902 unchanged. New dedicated2891 instance/data retained; one compute-heavy task at a time. All logs use exclusive paths. Shared build_release changes identity deliberately; sealed binaries remain available.

Build/runtime/performance have a90-minute bound from stage runner start. No repeated attempts seeking a favorable score. If target baseline cannot normally build, retain exact failure, report target blocker and open a Draft PR with prior standalone correctness and static integration evidence; do not repair unrelated AI/FileSQL code. If candidate fails, diagnose only #6-induced issues or publish a blocked Draft PR honestly.

Correctness: final target/candidate FTS15/15, target/candidate File SQL1/1 as a no-regression comparison, ownership/capacity candidate tests, ordered semantic differential and file-text→TOKENIZE→storedFTS smoke. Use untouched official test SQL/data/goldens; fixture transport may be adapted locally with unchanged bytes and recorded environment.

Performance is one bounded exploratory batch intended to test effect quickly: one same-baseline A/A control pair (diagnostic point estimate only), then three target±#6 pairs in AB/BA/AB order. Run complete fixed official workload ROWS20000 BATCH500 ROUNDS3000 QUERY_ROUNDS200 SAMPLES3 WARMUP30 SKIP_LOAD0; verify hits8001/11000/7332/20. Shared ERROR logging/20s cooldown/affinityserver0-3/client4, same boot; no other builds/profilers during timing. Record9metrics, category-weighted paired change,95% Student-t interval df2 factor4.302653, each control and server CPU/lifetime peak RSS. All samples retained, no pooling with previous windows. One A/A pair is not a validated noise interval; label results exploratory, not a qualification replacing earlier failed calibration. If control point>5% or SQL control>8%/rawload>15%, report noise as a limitation, but retain permitted exploratory A/B to answer the user's trial request. Do not present noisy data as proven speedup.

PR is Draft unless integrated correctness passes and evidence supports a useful comprehensive gain with uncertainty and resource limits stated. Minimum useful point2%, lower95% bound>0, category mean regressions<=3%, individual metric regressions<=10%, per-pair select1<=8%/rawload<=15%, RSS mean regression<=5%; A/A is diagnostic only, so even satisfying these does not override lack of stronger calibration. No more optimization/retry/confirmation in this closeout. PR body must expose observed negative or inconclusive outcome, not old16.8%.

## Tasks

- [ ] Pin remote target, verify native clean state, protect old refs/binaries/data and create dedicated integration branch.
- [ ] Normal baseline Release build with repository-required generated artifacts; seal binary or exact baseline build blocker.
- [ ] Apply existing reviewed product+tests patch, commit #6-only candidate, normal build and candidate focused tests.
- [ ] Fresh isolated integrated correctness and exploratory control/three pairs if builds permit; stop only new instances and verify inputs/identities.
- [ ] One fresh read-only whole-PR review, resolve material #6 findings, write eight-section handoff/patch/fourlogs/before-after data with limitations.
- [ ] Push only dedicated PR branch and create PR targeting feat/seekdb-all; verify URL/base/head/diff/status, preserve local evidence archive.

## Review focus

Exact #6 delta against integrated base; no stale generated variables or transplanted #2 fixes; caller token ownership and Unicode capacity fix; baseline build failures attributed to target, not hidden by changing other tasks; exploratory timing versus qualified gain explicit; original server and all data protected; no credentials or large native binaries in PR.
