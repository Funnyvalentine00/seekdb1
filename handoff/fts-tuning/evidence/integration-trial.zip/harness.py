"""Unique, bounded, serial FTS qualification; never reset data or touch old servers."""
from pathlib import Path
import datetime, hashlib, json, math, os, resource, shutil, signal, socket, statistics, subprocess, sys, time, traceback

OUT = Path(__file__).resolve().parent
PROJECT = OUT.parents[2]
NATIVE = Path('/opt/codex-seekdb-20261030')
sys.path.insert(0, str(OUT / 'support'))
from processes import run_managed, terminate_group
from analyze import validate, signed_improvement, REFERENCE, KEYS, analyze

PORT = 2891
INSTANCE = Path('/opt/codex-fts-integration-pr-20261102')
TREES = {k: NATIVE for k in ('original','candidate')}
SOURCES = json.loads((OUT/'SOURCE_RECORD.json').read_text())
SOURCE_COMMITS = {'original': SOURCES['base'], 'candidate': SOURCES['candidate']}
correctness_callback = None
BUILDS = {k: json.loads((OUT/(tag+'-build.json')).read_text()) for k,tag in (('original','baseline'),('candidate','candidate'))}
BINARIES = {k:(Path(v['saved_binary']).name,v['binary_sha256']) for k,v in BUILDS.items()}
DEADLINE = time.monotonic() + max(1,json.loads((OUT/'STAGE.json').read_text())['deadline_epoch']-time.time())
BOOT = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
STATE = {'started_at': datetime.datetime.now().astimezone().isoformat(), 'boot_id': BOOT,
         'protocol_sha256': hashlib.sha256((OUT / 'PROTOCOL.md').read_bytes()).hexdigest(),
         'status': 'running', 'runs': [], 'events': []}
SERVER = None
ENV = os.environ.copy()
ENV['LD_LIBRARY_PATH'] = str(NATIVE / 'deps/3rd/u01/obclient/lib') + ':' + ENV.get('LD_LIBRARY_PATH', '')
CLIENT = [str(NATIVE / 'deps/3rd/u01/obclient/bin/obclient'), '--no-defaults', '-h127.0.0.1', '-P' + str(PORT), '-uroot', '--default-character-set=utf8mb4']

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''): h.update(b)
    return h.hexdigest()

def save():
    STATE['updated_at'] = datetime.datetime.now().astimezone().isoformat()
    tmp = OUT / 'state.next'
    tmp.write_text(json.dumps(STATE, indent=2) + '\n'); tmp.replace(OUT / 'state.json')

def event(message):
    row = {'at': datetime.datetime.now().astimezone().isoformat(), 'message': message}
    STATE['events'].append(row); save(); print(row, flush=True)

def guard():
    assert time.monotonic() < DEADLINE, '90 minute execution budget exhausted'
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == BOOT, 'WSL boot changed'
    assert Path('/proc/7902/stat').read_text().rsplit(')', 1)[1].split()[19] == STATE['old_server_start_ticks']

def command(args, log, timeout=240, stdin=None, cwd=None, env=None):
    guard()
    with log.open('x') as f:
        f.write('COMMAND ' + repr(args) + '\n'); f.flush()
        started = time.monotonic()
        code = run_managed(args, cwd=cwd, env=env or ENV, stdin=stdin, stdout=f, stderr=subprocess.STDOUT,
                           timeout=min(timeout, DEADLINE-time.monotonic()))
        f.write(f'\nexit_code={code}\nseconds={time.monotonic()-started:.6f}\n')
    assert code == 0, f'Command failed: {log.name}: {code}'

def protected():
    names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '5bce9e0',
        'tools/deploy/init.sql', 'tools/deploy/init_user.sql', 'tools/deploy/mysql_test/test_suite/fts_index', 'tools/deploy/mysql_test/test_suite/file_sql', 'tools/benchmark'], cwd=NATIVE, text=True).splitlines()
    result = {}
    for n in names:
        blob = subprocess.check_output(['git', 'show', '5bce9e0:' + n], cwd=NATIVE)
        result[n] = hashlib.sha256(blob).hexdigest()
        for tree in TREES.values(): assert (tree / n).read_bytes() == blob, str(tree / n)
    return result

def status(pid):
    result = {}
    for line in Path(f'/proc/{pid}/status').read_text().splitlines():
        if line.startswith(('VmRSS:', 'VmHWM:', 'VmSwap:', 'Threads:')):
            k, v = line.split(':', 1); result[k] = int(v.strip().split()[0])
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    result.update(cpu_ticks=int(fields[11])+int(fields[12]), start_ticks=int(fields[19]))
    return result

def stop():
    global SERVER
    if SERVER is not None:
        if SERVER.poll() is None:
            assert Path(f'/proc/{SERVER.pid}/exe').resolve().parent == INSTANCE / 'bin'
            os.killpg(SERVER.pid, signal.SIGTERM)
            try:
                SERVER.wait(timeout=30)
            except subprocess.TimeoutExpired:
                STATE.setdefault('forced_stops', []).append(SERVER.pid)
                terminate_group(SERVER)
        tag = STATE.get('active')
        if tag and (OUT / tag).is_dir():
            destination = OUT / tag / 'server-logs'
            destination.mkdir(exist_ok=False)
            for path in (INSTANCE / 'log').glob('seekdb.log*'):
                if path.is_file() and not path.is_symlink():
                    shutil.copy2(path, destination / path.name)
        STATE['last_stopped_pid'] = SERVER.pid
        SERVER = None; save()

def start(version, tag):
    global SERVER
    stop(); guard()
    logs = OUT / tag; logs.mkdir(exist_ok=False)
    tree = TREES[version]
    binary = INSTANCE / 'bin' / ('seekdb-' + version)
    args = ['taskset', '-c', '0-3', str(binary), '--nodaemon', '--port', str(PORT),
        '--log-level', 'ERROR', '--base-dir', str(INSTANCE), '--data-dir', str(INSTANCE / 'store'),
        '--parameter', 'memory_budget=4G', '--parameter', 'datafile_size=4G',
        '--parameter', 'datafile_maxsize=8G', '--parameter', 'log_disk_size=2G', '--parameter', 'cpu_count=4']
    with (logs / 'console.log').open('x') as f:
        SERVER = subprocess.Popen(args, cwd=INSTANCE, env=ENV, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    run = {'tag': tag, 'version': version, 'pid': SERVER.pid, 'command': args,
        'source_commit': SOURCE_COMMITS[version],
        'binary_sha256': BINARIES[version][1], 'started_at': datetime.datetime.now().astimezone().isoformat()}
    STATE['runs'].append(run); STATE['active'] = tag; save()
    deadline = time.monotonic()+180
    while True:
        guard(); assert SERVER.poll() is None, 'new server exited'
        try:
            p = subprocess.run(CLIENT+['--connect-timeout=1','-N','-s','-e','SELECT 1'], env=ENV, capture_output=True, timeout=3)
        except subprocess.TimeoutExpired:
            run['readiness_query_timeouts'] = run.get('readiness_query_timeouts', 0) + 1
            assert time.monotonic() < deadline, 'server readiness timeout'
            continue
        if p.returncode == 0 and p.stdout.strip() == b'1': break
        assert time.monotonic() < deadline, 'server readiness timeout'
        time.sleep(1)
    assert sha(Path(f'/proc/{SERVER.pid}/exe')) == BINARIES[version][1]
    run['process_start_ticks'] = status(SERVER.pid)['start_ticks']
    run['readiness_seconds'] = 180 - (deadline-time.monotonic())
    event(tag + ': original initialization and full FTS suite')
    with (tree / 'tools/deploy/init.sql').open('rb') as sql:
        command(CLIENT, logs/'init.log', stdin=sql, cwd=tree/'tools/deploy', timeout=180)
    local = [str(NATIVE/'deps/3rd/u01/obclient/bin/obclient'), '--no-defaults', '--socket='+str(INSTANCE/'run/sql.sock'), '-uroot']
    command(local+['-e', "SET GLOBAL secure_file_priv='"+str(INSTANCE)+"';"], logs/'secure-file.log', timeout=15)
    suite = tree / 'tools/deploy/mysql_test/test_suite/fts_index'
    cases = []
    env = ENV | {'PWD': str(tree/'tools/deploy')}
    for test in sorted((suite/'t').glob('*.test')):
        driver = logs/(test.stem+'.driver')
        driver.write_text(f'let $OBMYSQL_MS0 = 127.0.0.1;\nlet $OBMYSQL_PORT = {PORT};\nlet $OBMYSQL_PWD = admin;\nlet $OBSERVER_DIR = {INSTANCE};\n--source {test}\n')
        expected = logs/(test.stem+'.result')
        shutil.copy2(suite/'r/mysql'/(test.stem+'.result'), expected)
        args = [str(NATIVE/'deps/3rd/u01/obclient/bin/mysqltest'), '--no-defaults', '--host=127.0.0.1', '--port='+str(PORT),
            '--user=root', '--database=test', '--default-character-set=utf8mb4', '--test-file='+str(driver), '--result-file='+str(expected)]
        began = time.monotonic()
        command(args, logs/(test.stem+'.log'), timeout=240, cwd=tree/'tools/deploy', env=env)
        cases.append({'name': test.stem, 'seconds': time.monotonic()-began, 'exit_code': 0})
        run['official_cases'] = cases; save()
    assert len(cases) == 15
    with (OUT/'semantic.sql').open('rb') as sql:
        command(CLIENT+['-N','-s','--force'], logs/'semantic.out', stdin=sql, timeout=90)
    data = (logs/'semantic.out').read_text().split('\nexit_code=')[0].split('\n',1)[1]
    run['semantic_output_sha256'] = hashlib.sha256(data.encode()).hexdigest()
    expected = OUT/'semantic-original.out'
    if not expected.exists():
        assert version == 'original'; expected.write_text(data)
    assert data == expected.read_text(), 'semantic differential mismatch'
    run['correctness_passed'] = True; save()
    if correctness_callback is not None:
        correctness_callback(version, logs, run)
    event(tag + ': fixed20s cooldown')
    time.sleep(20)
    return logs, run

def bench(version, tag, report_dir=None, report_name=None):
    logs, run = start(version, tag)
    event(tag + ': fixed official workload')
    label = 'before' if version == 'original' else 'after'
    report = (report_dir/report_name) if report_dir else logs/'report.txt'
    assert not report.exists()
    env = ENV | {'MYSQL': ' '.join(CLIENT+['-N','-s','-A']), 'MYSQL_VERBOSE': ' '.join(CLIENT),
        'LABEL': label, 'ROWS':'20000', 'BATCH':'500', 'ROUNDS':'3000','QUERY_ROUNDS':'200',
        'SAMPLES':'3','WARMUP':'30','SKIP_LOAD':'0','OUTPUT':str(report)}
    initial = status(SERVER.pid); began = time.monotonic()
    command(['taskset','-c','4','bash','tools/benchmark/fts_large_bench.sh'], logs/'benchmark.log',
            timeout=600, cwd=TREES[version], env=env)
    final = status(SERVER.pid)
    assert initial['start_ticks'] == final['start_ticks']
    metrics = validate(report, label)
    resource_result = {'pid': SERVER.pid, 'initial': initial, 'final': final,
        'cpu_seconds': (final['cpu_ticks']-initial['cpu_ticks'])/os.sysconf('SC_CLK_TCK'),
        'server_lifetime_peak_rss_kib': final['VmHWM'], 'wall_seconds':time.monotonic()-began, 'benchmark_exit_code':0}
    (logs/'resources.json').write_text(json.dumps(resource_result, indent=2)+'\n')
    if report_dir:
        shutil.copy2(logs/'benchmark.log', report.with_suffix('.log'))
        report.with_suffix('.resources.json').write_text(json.dumps(resource_result, indent=2)+'\n')
    run['report'] = str(report); run['metrics'] = metrics; run['resources'] = resource_result
    run['completed'] = True; save(); stop()
    return metrics

def controls(a,b):
    return {k: abs(b[k]/a[k]-1) for k in ('select1_avg_ms','raw_load_sec')}

def summarize(pairs, directory, confirmation=False):
    improvements = [signed_improvement(a,b) for a,b in pairs]
    cats = {c: statistics.mean(statistics.mean((a[k]-b[k])/a[k] for k in ks) for a,b in pairs)
            for c,ks in REFERENCE['score_categories'].items()}
    metrics = {k: statistics.mean((a[k]-b[k])/a[k] for a,b in pairs) for k in KEYS}
    control = [controls(a,b) for a,b in pairs]
    point = statistics.mean(improvements)
    ci = [point-2.776445*statistics.stdev(improvements)/math.sqrt(5), point+2.776445*statistics.stdev(improvements)/math.sqrt(5)] if not confirmation else None
    gates = {'minimum_useful_gain': point >= .02, 'positive_interval': min(improvements)>0 if confirmation else ci[0]>0,
        'category_regression': min(cats.values())>=-.03, 'metric_regression': min(metrics.values())>=-.1,
        'controls': all(c['select1_avg_ms']<=.08 and c['raw_load_sec']<=.15 for c in control)}
    result = {'pairs':len(pairs), 'mean_improvement':point, 'primary_95_interval':ci,
        'paired_improvements':improvements, 'category_improvements':cats, 'metric_improvements':metrics,
        'controls':control, 'gates':gates, 'qualified':all(gates.values()), 'confirmation':confirmation}
    (directory/'decision.json').write_text(json.dumps(result, indent=2)+'\n')
    analyze(directory)
    return result

