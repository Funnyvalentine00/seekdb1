from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,traceback
out=Path(__file__).resolve().parent;native=Path('/opt/codex-seekdb-20261030')
tag=sys.argv[1];assert tag in ('baseline','candidate')
assert not (out/(tag+'-build.json')).exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=native,text=True).strip()
assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=native)
if tag=='baseline':assert head=='fdb8363f64363819fcf2307be95bcd10a5a7e4ba'
stage=out/'STAGE.json'
if not stage.exists():stage.write_text(json.dumps({'started_epoch':time.time(),'deadline_epoch':time.time()+5400,'max_minutes':90},indent=2)+'\n')
deadline=json.loads(stage.read_text())['deadline_epoch']
environment=dict(os.environ,CARGO_HOME='/opt/codex-seekdb-toolchain-20261030/cargo',RUSTUP_HOME='/opt/codex-seekdb-toolchain-20261030/rustup')
commands=[]
if tag=='baseline':
    commands=[(['bash','gen_parser.sh'],native/'src/sql/parser'),
        (['python3','generate_inner_table_schema.py'],native/'src/share/inner_table')]
commands.append((['make','-C','build_release','-j4'],native))
result={'tag':tag,'source_commit':head,'status':'building','started_at':datetime.datetime.now().astimezone().isoformat(),
    'commands':[{'argv':argv,'cwd':str(cwd)} for argv,cwd in commands]}
meta=out/(tag+'-build.json');meta.write_text(json.dumps(result,indent=2)+'\n')
began=time.monotonic()
try:
    with (out/(tag+'-build.log')).open('x') as log:
        for argv,cwd in commands:
            log.write('COMMAND '+repr(argv)+' CWD '+str(cwd)+'\n');log.flush()
            run=subprocess.run(argv,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=min(2400,max(1,deadline-time.time())))
            log.write('\nexit_code='+str(run.returncode)+'\n');log.flush()
            if run.returncode!=0:
                result.update(status='failed',failed_command=argv,exit_code=run.returncode);break
        else:
            assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=native), 'Generation changed tracked source; capture and inspect before claiming clean base.'
            binary=native/'build_release/src/observer/seekdb';saved=native/'saved-binaries'/('fts-integration-'+tag+'-20261102')
            assert not saved.exists();subprocess.run(['cp','--reflink=auto',str(binary),str(saved)],check=True)
            digest=hashlib.sha256()
            with saved.open('rb') as f:
                for block in iter(lambda:f.read(8*1024*1024),b''):digest.update(block)
            result.update(status='built',exit_code=0,saved_binary=str(saved),binary_sha256=digest.hexdigest())
except BaseException as error:
    result.update(status='failed',error=repr(error));(out/(tag+'-build-error.log')).write_text(traceback.format_exc())
finally:
    result.update(seconds=time.monotonic()-began,finished_at=datetime.datetime.now().astimezone().isoformat())
    meta.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));assert result['status']=='built'
