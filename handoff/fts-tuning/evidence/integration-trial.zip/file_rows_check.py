"""Post-trial review fix: verify actual CSV-derived tokens, indexed IDs and scores."""
from pathlib import Path
import csv,json,resource,socket,subprocess,time
import harness as h
out=Path(__file__).resolve().parent
prior=json.loads((out/'state.json').read_text());assert prior['status']=='exploratory_complete'
logs=out/'file-rows-check';logs.mkdir(exist_ok=False)
h.OUT=logs
s=socket.socket();s.bind(('127.0.0.1',h.PORT));s.close()
soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE);resource.setrlimit(resource.RLIMIT_NOFILE,(min(65536,hard),hard))
h.STATE={'status':'running','runs':[],'events':[],
    'old_server_start_ticks':prior['old_server_start_ticks'],'old_server_binary_sha256':prior['old_server_binary_sha256'],
    'protected_before':h.protected(),'review_fix':'Actual CSV names, expected IDs and scores, nonempty TOKENIZE; basic hello-only smoke is insufficient.'}
data=h.NATIVE/'tools/deploy/mysql_test/test_suite/file_sql/data/basic.csv'
with data.open(newline='') as f: rows=list(csv.reader(f))[1:]
names={int(r[0]):r[1].lower() for r in rows}
assert all(name.isascii() and name.isalpha() for name in names.values())
smoke=h.INSTANCE/'fts-file-smoke';assert (smoke/'basic.csv').read_bytes()==data.read_bytes()
values=','.join('('+str(int(row[0]))+',CONVERT(0x'+row[1].encode().hex()+' USING utf8mb4))' for row in rows)
sql=f'''SET SESSION enable_file_sql=ON;
DROP DATABASE IF EXISTS fts_actual_file_rows;
CREATE DATABASE fts_actual_file_rows;
USE fts_actual_file_rows;
CREATE TABLE imported(id BIGINT PRIMARY KEY,doc VARCHAR(4000),FULLTEXT INDEX ft(doc) WITH PARSER beng);
CREATE TABLE literal_docs LIKE imported;
INSERT INTO imported SELECT id,name FROM read_csv('{smoke}/basic.csv');
INSERT INTO literal_docs VALUES {values};
SELECT 'import_token',id,HEX(tokenize(doc,'beng','[{{"output":"all"}}]')) FROM imported ORDER BY id;
SELECT 'literal_token',id,HEX(tokenize(doc,'beng','[{{"output":"all"}}]')) FROM literal_docs ORDER BY id;
'''
for name in names.values():
    for label,table in (('import_match','imported'),('literal_match','literal_docs')):
        sql+=f"SELECT '{label}_{name}',id,ROUND(MATCH(doc) AGAINST('{name}'),6) FROM {table} WHERE MATCH(doc) AGAINST('{name}') ORDER BY id;\n"
sql+='DROP DATABASE fts_actual_file_rows;\nSET SESSION enable_file_sql=OFF;\n'
(logs/'check.sql').write_text(sql);h.save()
try:
    reference=None
    for version in ('original','candidate'):
        runlog=logs/version;runlog.mkdir()
        args=next(r['command'] for r in prior['runs'] if r['version']==version)
        with (runlog/'console.log').open('x') as f:
            h.SERVER=subprocess.Popen(args,cwd=h.INSTANCE,env=h.ENV,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        run={'tag':version,'pid':h.SERVER.pid,'source_commit':h.SOURCE_COMMITS[version],'binary_sha256':h.BINARIES[version][1]}
        h.STATE['runs'].append(run);h.STATE['active']=version;h.save()
        deadline=time.monotonic()+180
        while True:
            h.guard();assert h.SERVER.poll() is None
            try:p=subprocess.run(h.CLIENT+['--connect-timeout=1','-N','-s','-e','SELECT 1'],env=h.ENV,capture_output=True,timeout=4)
            except subprocess.TimeoutExpired:
                assert time.monotonic()<deadline;continue
            if p.returncode==0 and p.stdout.strip()==b'1':break
            assert time.monotonic()<deadline;time.sleep(1)
        assert h.sha(Path('/proc/'+str(h.SERVER.pid)+'/exe'))==h.BINARIES[version][1]
        with (h.NATIVE/'tools/deploy/init.sql').open('rb') as f:
            h.command(h.CLIENT,runlog/'init.log',stdin=f,cwd=h.NATIVE/'tools/deploy',timeout=180)
        local=[str(h.NATIVE/'deps/3rd/u01/obclient/bin/obclient'),'--no-defaults','--socket='+str(h.INSTANCE/'run/sql.sock'),'-uroot']
        h.command(local+['-e',"SET GLOBAL secure_file_priv='"+str(h.INSTANCE)+"';"],runlog/'secure-file.log',timeout=15)
        with (logs/'check.sql').open('rb') as f:h.command(h.CLIENT+['-N','-s'],runlog/'check.out',stdin=f,timeout=90)
        raw=(runlog/'check.out').read_text().split('\nexit_code=')[0].split('\n',1)[1]
        if reference is None:reference=raw
        assert raw==reference,'Actual file-source FTS changed'
        result={}
        for line in raw.splitlines():
            label,rowid,value=line.split('\t');result.setdefault(label,[]).append((int(rowid),value))
        assert result['import_token']==result['literal_token']
        assert {i for i,_ in result['import_token']}==set(names)
        for i,encoded in result['import_token']:
            token=json.loads(bytes.fromhex(encoded));assert token['tokens']==[{names[i]:1}] and token['doc_len']==1
        for rowid,name in names.items():
            a=result['import_match_'+name];b=result['literal_match_'+name]
            assert a==b and [i for i,_ in a]==[rowid] and float(a[0][1])>0,(name,a,b)
        (runlog/'verified.json').write_text(json.dumps({'expected_file_ids':sorted(names),'tokens_and_scores_equal_to_literal':True,'nonempty':True},indent=2)+'\n')
        run['actual_file_rows_verified']=True;h.save();h.stop()
    h.STATE['status']='passed'
except BaseException as error:
    h.STATE.update(status='failed',error=repr(error));raise
finally:
    h.stop();h.STATE['protected_after']=h.protected();assert h.STATE['protected_before']==h.STATE['protected_after']
    assert h.sha(Path('/proc/7902/exe'))==h.STATE['old_server_binary_sha256'];h.save()
print('Actual file-derived names: tokens, expected indexed IDs and scores verified on baseline/candidate.',flush=True)
