"""One exploratory integrated trial; never retry/select/pool samples."""
from pathlib import Path
import csv,datetime,json,math,os,resource,shlex,shutil,socket,statistics,subprocess,time,traceback
import harness as h
out=Path(__file__).resolve().parent

def extra_correctness(version,logs,run):
    # Same preconditions on every restart: File SQL and file-text/FTS smoke precede timing.
    suite=h.NATIVE/'tools/deploy/mysql_test/test_suite/file_sql'
    driver=logs/'file_sql_basic.driver'
    driver.write_text(f'let $OBMYSQL_MS0 = 127.0.0.1;\nlet $OBMYSQL_PORT = {h.PORT};\nlet $OBMYSQL_PWD = admin;\nlet $OBSERVER_DIR = {h.INSTANCE};\n--source {suite}/t/file_sql_basic.test\n')
    expected=logs/'file_sql_basic.result';shutil.copy2(suite/'r/mysql/file_sql_basic.result',expected)
    args=[str(h.NATIVE/'deps/3rd/u01/obclient/bin/mysqltest'),'--no-defaults','--host=127.0.0.1','--port='+str(h.PORT),
        '--user=root','--database=test','--default-character-set=utf8mb4','--test-file='+str(driver),'--result-file='+str(expected)]
    try:
        h.command(args,logs/'file_sql_basic.log',timeout=240,cwd=h.NATIVE/'tools/deploy',env=h.ENV|{'PWD':str(h.NATIVE/'tools/deploy')})
        run['file_sql_passed']=True
    except AssertionError as error:
        run['file_sql_passed']=False;run['file_sql_error']=str(error)
        h.event(run['tag']+': File SQL baseline/combination limitation retained; no unrelated fix')
    smoke=h.INSTANCE/'fts-file-smoke';smoke.mkdir(exist_ok=True)
    shutil.copy2(suite/'data/basic.csv',smoke/'basic.csv')
    with (suite/'data/basic.csv').open(newline='') as f: rows=list(csv.reader(f))[1:]
    values=','.join('('+str(int(row[0]))+',CONVERT(0x'+row[1].encode().hex()+' USING utf8mb4))' for row in rows)
    sql=f'''SET SESSION enable_file_sql=ON;
DROP DATABASE IF EXISTS fts_file_interaction;
CREATE DATABASE fts_file_interaction;
USE fts_file_interaction;
SELECT id,HEX(tokenize(name,'beng')) FROM read_csv('{smoke}/basic.csv') ORDER BY id;
CREATE TABLE imported(id BIGINT PRIMARY KEY,doc VARCHAR(4000),FULLTEXT INDEX ft(doc) WITH PARSER beng);
CREATE TABLE literal_docs LIKE imported;
INSERT INTO imported SELECT id,name FROM read_csv('{smoke}/basic.csv');
INSERT INTO literal_docs VALUES {values};
INSERT INTO imported VALUES(1000,NULL),(1001,''),(1002,'HELLO hello world');
INSERT INTO literal_docs VALUES(1000,NULL),(1001,''),(1002,'HELLO hello world');
SELECT id,HEX(tokenize(doc,'beng')) FROM imported ORDER BY id;
SELECT id,ROUND(MATCH(doc) AGAINST('hello'),6) FROM imported WHERE MATCH(doc) AGAINST('hello') ORDER BY id;
SELECT id,ROUND(MATCH(doc) AGAINST('hello'),6) FROM literal_docs WHERE MATCH(doc) AGAINST('hello') ORDER BY id;
SELECT 'import_hits',COUNT(*) FROM imported WHERE MATCH(doc) AGAINST('hello');
SELECT 'direct_hits',COUNT(*) FROM literal_docs WHERE MATCH(doc) AGAINST('hello');
DROP DATABASE fts_file_interaction;
SET SESSION enable_file_sql=OFF;
SELECT 'off_token',HEX(tokenize('HELLO world','beng'));
'''
    (logs/'file-fts-smoke.sql').write_text(sql)
    with (logs/'file-fts-smoke.sql').open('rb') as f:
        h.command(h.CLIENT+['-N','-s'],logs/'file-fts-smoke.out',timeout=90,stdin=f)
    data=(logs/'file-fts-smoke.out').read_text().split('\nexit_code=')[0].split('\n',1)[1]
    assert 'import_hits\t1\n' in data and 'direct_hits\t1\n' in data
    reference=out/'file-smoke-original.out'
    if not reference.exists():assert version=='original';reference.write_text(data)
    assert data==reference.read_text(),'file-text/FTS output changed'
    run['file_fts_smoke_passed']=True;h.save()

def main():
    assert not (out/'state.json').exists() and not h.INSTANCE.exists()
    assert all(v['status']=='built' for v in h.BUILDS.values())
    assert {0,1,2,3,4}<=os.sched_getaffinity(0)
    s=socket.socket();assert s.connect_ex(('127.0.0.1',h.PORT))!=0;s.close()
    soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE);resource.setrlimit(resource.RLIMIT_NOFILE,(min(65536,hard),hard))
    assert not subprocess.check_output(['git','diff','HEAD','--','src','unittest'],cwd=h.NATIVE)
    for name in ('bin','etc','log'):(h.INSTANCE/name).mkdir(parents=True,exist_ok=True)
    for name in ('admin','lib'):shutil.copytree(Path('/opt/codex-review-fts-20261101')/name,h.INSTANCE/name)
    for version,(name,digest) in h.BINARIES.items():
        source=h.NATIVE/'saved-binaries'/name;assert h.sha(source)==digest
        shutil.copy2(source,h.INSTANCE/'bin'/('seekdb-'+version))
    envbin=out/'env/bin';envbin.mkdir(parents=True)
    for name in ('ssh','scp'):
        wrapper=envbin/name;wrapper.write_text('#!/bin/sh\nexec /usr/bin/python3 '+shlex.quote(str(out/'transport.py'))+' '+name+' "$@"\n');wrapper.chmod(0o755)
    h.ENV['PATH']=str(envbin)+':'+h.ENV['PATH'];h.ENV['PWD']=str(h.NATIVE/'tools/deploy')
    (out/'semantic.sql').write_bytes((out.parent/'20261102-beng-resource/runtime/semantic.sql').read_bytes())
    h.STATE.update(old_server_start_ticks=Path('/proc/7902/stat').read_text().rsplit(')',1)[1].split()[19],
        old_server_binary_sha256=h.sha(Path('/proc/7902/exe')),protected_before=h.protected(),
        runner_sha256=h.sha(Path(__file__)),harness_sha256=h.sha(out/'harness.py'),
        exploratory_only=True,previous_samples_pooled=False,
        environment={'server_log_level':'ERROR','cooldown_seconds':20,'server_affinity':'0-3','client_affinity':'4'})
    h.correctness_callback=extra_correctness;h.save()
    try:
        h.event('One A/A diagnostic pair, followed by three predeclared AB/BA/AB pairs')
        a=h.bench('original','control-a');b=h.bench('original','control-b')
        control={'same_binary':True,'paired_weighted_change':h.signed_improvement(a,b),'controls':h.controls(a,b),
            'warning':'One pair is diagnostic only, not a noise confidence interval.'}
        (out/'control.json').write_text(json.dumps(control,indent=2)+'\n');h.STATE['control']=control;h.save()
        directory=out/'trial';directory.mkdir();pairs=[]
        for i,order in enumerate((('original','candidate'),('candidate','original'),('original','candidate')),1):
            values={}
            for version in order:
                label='before' if version=='original' else 'after'
                values[version]=h.bench(version,f'trial-{label}-{i:02}',directory,f'{label}-{i:02}.txt')
            pairs.append((values['original'],values['candidate']))
        changes=[h.signed_improvement(a,b) for a,b in pairs];point=statistics.mean(changes)
        half=4.302653*statistics.stdev(changes)/math.sqrt(3);ci=[point-half,point+half]
        metrics={k:statistics.mean((a[k]-b[k])/a[k] for a,b in pairs) for k in h.KEYS}
        categories={k:statistics.mean(metrics[m] for m in ms) for k,ms in h.REFERENCE['score_categories'].items()}
        controls=[h.controls(a,b) for a,b in pairs]
        rss={label:[json.loads(p.read_text())['server_lifetime_peak_rss_kib'] for p in sorted(directory.glob(label+'-*.resources.json'))] for label in ('before','after')}
        rss_change=statistics.mean(rss['after'])/statistics.mean(rss['before'])-1
        gates={'point_ge_2pct':point>=.02,'interval_lower_positive':ci[0]>0,
            'category_regression_le_3pct':min(categories.values())>=-.03,'metric_regression_le_10pct':min(metrics.values())>=-.1,
            'controls':all(c['select1_avg_ms']<=.08 and c['raw_load_sec']<=.15 for c in controls),
            'rss_mean_regression_le_5pct':rss_change<=.05,'file_sql_all_passed':all(r.get('file_sql_passed') for r in h.STATE['runs'])}
        result={'pairs':3,'paired_weighted_changes':changes,'mean_improvement':point,'student_t_95_interval':ci,
            'metric_improvements':metrics,'category_improvements':categories,'controls':controls,
            'server_lifetime_peak_rss_kib':rss,'rss_mean_change':rss_change,'gates':gates,
            'exploratory_only':True,'performance_qualified':False,'draft_pr':True,
            'limitation':'Small exploratory sample and only one A/A diagnostic; not a replacement for failed historical calibration.'}
        (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
        h.STATE['result']=result;h.STATE['status']='exploratory_complete';h.save()
        h.analyze(directory)
    except BaseException as error:
        h.STATE['status']='failed';h.STATE['error']=repr(error);(out/'error.log').write_text(traceback.format_exc());raise
    finally:
        h.stop();h.STATE['protected_after']=h.protected();assert h.STATE['protected_before']==h.STATE['protected_after']
        assert h.sha(Path('/proc/7902/exe'))==h.STATE['old_server_binary_sha256']
        h.STATE['old_server_unchanged']=True;h.STATE['finished_at']=datetime.datetime.now().astimezone().isoformat();h.save()
    print(json.dumps(h.STATE['result'],indent=2),flush=True)

if __name__=='__main__':main()
